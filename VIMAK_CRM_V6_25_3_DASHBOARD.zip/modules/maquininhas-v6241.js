/* V6.24.1 — Maquininhas & Taxas isolated extension */
(function(){
  const S = {
    tab: "simulador",
    inf: {
      "confirmada":{label:"Link • 1 dia útil • condição confirmada",pix:null,debit:null,credit:[null,null,null,null,null,null,null,null,null,null,null,16.66]}
    },
    mp: {
      "confirmar":{label:"Taxas ainda não confirmadas",pix:null,debit:null,credit:Array(18).fill(null)}
    },
    leoConfirmed:{installments:12,rate:14.84,creditPct:20,label:"Maquininha • 12x • condição confirmada em 16/09/2026"}
  };

  function key(){ return `vimak-payment-${company?.id||"local"}`; }
  function cfg(){ try{return JSON.parse(localStorage.getItem(key())||"{}")}catch(_){return {}} }
  function saveCfg(v){ localStorage.setItem(key(),JSON.stringify(v)); }
  function leo(){
    const db=(cache.cardMachines||[]).find(x=>(x.provider||"").toLowerCase()==="leozinha");
    const local=cfg().leo||{};
    const ir=db?.installment_rates||{};
    const rates=Array.isArray(ir)?ir:(ir.credit||local.credit||[]);
    return {
      pix:(Array.isArray(ir)?local.pix:ir.pix)??local.pix??null,
      debit:db?.debit_rate??local.debit??null,
      credit:Array.from({length:18},(_,i)=>rates[i]??(i===11?S.leoConfirmed.rate:null))
    };
  }
  function rate(provider,kind,n,infTier,mpTier){
    n=Math.max(1,Number(n)||1);
    if(provider==="InfinitePay"){
      const d=S.inf[infTier]||S.inf["confirmada"];
      return kind==="Pix"?d.pix:kind==="Débito"?d.debit:(n<=12?d.credit[n-1]:null);
    }
    if(provider==="Mercado Pago"){
      const d=S.mp[mpTier]||S.mp["confirmar"];
      return kind==="Pix"?d.pix:kind==="Débito"?d.debit:d.credit[Math.min(n,18)-1];
    }
    const d=leo();
    return kind==="Pix"?d.pix:kind==="Débito"?d.debit:d.credit[Math.min(n,18)-1];
  }
  function calc(provider,value,kind,n,infTier,mpTier){
    const r=rate(provider,kind,n,infTier,mpTier);
    if(r===null||r===undefined||r==="")return null;
    const pct=Number(r), fee=value*pct/100;
    return {provider,rate:pct,fee,net:value-fee,per:value/n};
  }

  window.paySafeSetTab=function(v){S.tab=v;render()};
  window.paySafeRemember=function(){
    const c=cfg();
    c.inf=document.getElementById("payInf")?.value||c.inf;
    c.mp=document.getElementById("payMp")?.value||c.mp;
    saveCfg(c); window.paySafeRun();
  };
  window.paySafeMode=function(){
    const k=document.getElementById("payKind"),n=document.getElementById("payN");
    if(k&&n){n.disabled=k.value!=="Crédito";if(n.disabled)n.value="1"}
    window.paySafeRun();
  };
  window.paySafeRun=function(){
    const value=Number(document.getElementById("payValue")?.value||0),
          kind=document.getElementById("payKind")?.value||"Crédito",
          n=kind==="Crédito"?Number(document.getElementById("payN")?.value||1):1,
          box=document.getElementById("payResult");
    if(!box)return;
    if(!value){box.innerHTML='<div class="notice">Informe o valor da venda.</div>';return}
    const candidates=[];
    const inf=calc("InfinitePay",value,kind,n,"confirmada","confirmar");
    if(inf) candidates.push({...inf,source:"CONFIRMADA • Link • 1 dia útil",economic:inf.net,bank:inf.net,leoCredit:0});
    const l=calc("Leozinha",value,kind,n,"confirmada","confirmar");
    if(l){
      const leoCredit=value*.20;
      const cardBase=value-leoCredit;
      const leoFee=cardBase*(l.rate/100);
      const bank=Math.max(0,cardBase-leoFee);
      const economic=bank+leoCredit;
      const effectiveRate=value?leoFee/value*100:0;
      candidates.push({...l,fee:leoFee,net:economic,source:(kind==="Crédito"&&n===12&&Number(l.rate)===14.84)?"CONFIRMADA • Maquininha • 12x":"CONTRATO CADASTRADO",economic,bank,leoCredit,cardBase,effectiveRate});
    }
    // Mercado Pago intentionally excluded until a real rate is confirmed/cadastrada.
    candidates.sort((a,b)=>b.economic-a.economic);
    const confirmedCount=candidates.length;
    if(!confirmedCount){box.innerHTML=`<div class="card pad"><div class="notice"><b>Sem condição confirmada para ${kind}${kind==="Crédito"?` ${n}x`:""}.</b><br>O CRM não usa taxas estimadas. Cadastre/valide a taxa antes de comparar.</div></div>`;return}
    const title=confirmedCount>=2?"COMPARAÇÃO DE CONDIÇÕES CONFIRMADAS":"CONDIÇÃO CONFIRMADA DISPONÍVEL";
    box.innerHTML=`<div class="card pad pay-safe-winner"><div class="fin-panel-head"><div><span>${title}</span><h3>${confirmedCount>=2?"Comparativo financeiro":candidates[0].provider}</h3></div><b class="goldtxt">${kind}${kind==="Crédito"?` • ${n}x`:""}</b></div>
      <div class="grid g3">${candidates.map(x=>`<div class="card kpi"><label>${x.provider}</label><strong>${x.rate.toFixed(2)}%</strong><small>${x.source}<br>${x.provider==="Leozinha"?`Nota LEO 20% ${money(x.leoCredit)} • Base cartão ${money(x.cardBase)}<br>Taxa 14,84% sobre 80% = ${money(x.fee)} • Taxa efetiva ${x.effectiveRate.toFixed(2)}%<br>Conta ${money(x.bank)} • Total recebido ${money(x.economic)}`:`Taxa ${money(x.fee)} • Líquido ${money(x.net)}`}${kind==="Crédito"?`<br>Cliente: ${n}x de ${money(x.per)}`:""}</small></div>`).join("")}</div>
      ${confirmedCount>=2?`<div class="notice"><b>Comparação objetiva:</b> os cartões acima usam somente taxas confirmadas/cadastradas. O CRM mostra os valores para você decidir; não utiliza taxas estimadas.</div>`:`<div class="notice"><b>Importante:</b> existe apenas uma condição confirmada para este cenário. Por isso o CRM não declara uma “melhor opção” sem dados equivalentes das demais adquirentes.</div>`}
      ${!rate("Mercado Pago",kind,n,"confirmada","confirmar")?'<div class="notice">Mercado Pago: <b>taxa não confirmada para esta condição</b> — fora da comparação.</div>':''}
    </div>`;
  };
  window.paySafeLeoSave=async function(){
    const c=cfg(),credit=[];
    for(let i=1;i<=18;i++){const v=document.getElementById("leo"+i).value;credit.push(v===""?null:Number(v))}
    c.leo={pix:document.getElementById("leoPix").value===""?null:Number(document.getElementById("leoPix").value),debit:document.getElementById("leoDeb").value===""?null:Number(document.getElementById("leoDeb").value),credit};
    saveCfg(c);
    const existing=(cache.cardMachines||[]).find(x=>(x.provider||"").toLowerCase()==="leozinha");
    const payload={company_id:profile.company_id,name:"Leozinha",provider:"Leozinha",debit_rate:c.leo.debit||0,credit_1x_rate:c.leo.credit[0]||0,installment_rates:{pix:c.leo.pix,credit:c.leo.credit},settlement_days:1,active:true};
    const r=existing?await sb.from("card_machines").update(payload).eq("id",existing.id):await sb.from("card_machines").insert(payload);
    if(r.error)return toast("Erro ao salvar taxas: "+r.error.message);
    await refreshCore();toast("Taxas da Leozinha salvas na nuvem");render();
  };

  function simulator(){
    setTimeout(window.paySafeRun,0);
    return `<div class="grid g2"><section class="card pad"><div class="fin-panel-head"><div><span>SMART PAYMENT ROUTER • DADOS CONFIRMADOS</span><h3>Simular venda</h3></div></div><div class="form-grid">
      <div class="field"><label>Valor</label><input id="payValue" type="number" step=".01" value="29700" oninput="paySafeRun()"></div>
      <div class="field"><label>Modalidade</label><select id="payKind" onchange="paySafeMode()"><option>Crédito</option><option>Débito</option><option>Pix</option></select></div>
      <div class="field"><label>Parcelas</label><select id="payN" onchange="paySafeRun()">${Array.from({length:18},(_,i)=>i+1).map(n=>`<option value="${n}" ${n===12?"selected":""}>${n}x</option>`).join("")}</select></div>
    </div><div class="notice"><b>Regra de segurança:</b> o CRM só compara taxas confirmadas pela VIMAK ou cadastradas no contrato. InfinitePay 12x: 16,66% (Link, 1 dia útil). Leozinha 12x: nota de crédito LEO de 20% do bruto + taxa de 14,84% aplicada somente aos 80% destinados à conta, resultando em taxa efetiva de aproximadamente 11,87%. Condições confirmadas em 16/09/2026.</div></section><section id="payResult"></section></div>`;
  }
  function rates(){
    const l=leo();
    return `<div class="card"><div class="table-wrap"><table class="table"><thead><tr><th>Parcelas</th><th>InfinitePay</th><th>Mercado Pago</th><th>Leozinha</th></tr></thead><tbody>${Array.from({length:18},(_,i)=>i+1).map(n=>`<tr><td>${n}x</td><td>${n===12?'<b>16,66% • CONFIRMADA</b>':'Aguardando taxa real'}</td><td>Aguardando taxa real</td><td>${l.credit[n-1]==null?'Configurar contrato':Number(l.credit[n-1]).toFixed(2)+(n===12?'% • CONFIRMADA • taxa sobre 80%':'% • cadastrada')}</td></tr>`).join("")}</tbody></table></div><div class="notice"><b>Regra Leozinha confirmada:</b> 20% do valor bruto vira Nota de Crédito LEO sem taxa. A taxa da maquininha incide sobre os 80% restantes. Em 12x, a taxa confirmada é 14,84% sobre essa base, equivalente a aproximadamente 11,87% sobre a venda total.</div></div>`;
  }
  function leoEdit(){
    const l=leo();
    return `<div class="card pad"><div class="fin-panel-head"><div><span>LEOZINHA</span><h3>Taxas do seu contrato</h3></div></div><div class="notice">Cadastre exatamente as taxas da sua operação. O CRM não inventa valores contratuais.</div>
      <div class="form-grid safe-admin-gap"><div class="field"><label>Pix %</label><input id="leoPix" type="number" step=".01" value="${l.pix??""}"></div><div class="field"><label>Débito %</label><input id="leoDeb" type="number" step=".01" value="${l.debit??""}"></div></div>
      <div class="pay-safe-rate-grid">${Array.from({length:18},(_,i)=>`<div class="field"><label>${i+1}x %</label><input id="leo${i+1}" type="number" step=".01" value="${l.credit[i]??""}"></div>`).join("")}</div>
      <button class="btn gold safe-admin-gap" onclick="paySafeLeoSave()">Salvar taxas</button></div>`;
  }
  function renderer(){
    const tabs=[["simulador","◎ Simulador"],["taxas","% Tabela de Taxas"],["leozinha","▣ Leozinha"]];
    return shell("Maquininhas & Taxas","InfinitePay • Mercado Pago • Leozinha • comparação somente com taxas confirmadas",
      `<button class="btn gold" onclick="paySafeSetTab('simulador')">◎ Simular venda</button>`,
      `<div class="fin-command"><div><span class="measurement-version">V6.24.1 • SAFE MODULE</span><h2>Central Inteligente de Pagamentos</h2><p>O módulo roda isolado do login e do carregamento principal.</p></div><div class="fin-command-badge"><span>ISOLATED ENGINE</span><b class="green">ATIVO</b></div></div>
      <div class="grid g3 proposal-kpis"><div class="card kpi"><label>InfinitePay</label><strong>12x confirmado</strong><small>Link • 1 dia útil • 16,66%</small></div><div class="card kpi"><label>Mercado Pago</label><strong>Aguardando taxas</strong><small>Fora da comparação até confirmação</small></div><div class="card kpi"><label>Leozinha</label><strong>12x confirmado</strong><small>20% Nota LEO + 14,84% sobre os 80% • efetiva ≈ 11,87%</small></div></div>
      <div class="fin-tabs">${tabs.map(x=>`<button class="${S.tab===x[0]?"active":""}" onclick="paySafeSetTab('${x[0]}')">${x[1]}</button>`).join("")}</div>
      ${S.tab==="simulador"?simulator():S.tab==="taxas"?rates():leoEdit()}`);
  }

  if(window.VIMAK_MODULES){
    window.VIMAK_MODULES.register("maquininhas",renderer,{version:"6.24.13.11.14",isolated:true});
    if(page==="maquininhas" && session){ try{render()}catch(_){} }
  }
})();
