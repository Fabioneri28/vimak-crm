-- VIMAK CRM V6.24.13.11.8 — Auditoria Geral 360°
-- Rastreia INSERT / UPDATE / DELETE nas principais tabelas do CRM,
-- registrando quem fez, quando, em qual módulo e o antes/depois.

alter table public.audit_logs add column if not exists user_email text;
alter table public.audit_logs add column if not exists user_name text;
alter table public.audit_logs add column if not exists module text;
alter table public.audit_logs add column if not exists operation text;
alter table public.audit_logs add column if not exists changed_fields text[] not null default '{}';
alter table public.audit_logs add column if not exists summary text;
alter table public.audit_logs add column if not exists source_app text not null default 'VIMAK CRM / API';

create index if not exists idx_audit_logs_company_created on public.audit_logs(company_id, created_at desc);
create index if not exists idx_audit_logs_company_user on public.audit_logs(company_id, user_id);
create index if not exists idx_audit_logs_company_table on public.audit_logs(company_id, table_name);
create index if not exists idx_audit_logs_company_action on public.audit_logs(company_id, action);

-- Remove credenciais e chaves que nunca devem ir para a auditoria.
create or replace function public.vimak_audit_sanitize(p_data jsonb)
returns jsonb language sql immutable as $$
 select case when p_data is null then null else
  p_data - array['password','senha','secret','token','access_token','refresh_token','api_key','service_role','service_role_key','anon_key','config']
 end
$$;

create or replace function public.vimak_audit_module(p_table text)
returns text language sql immutable as $$
 select case p_table
  when 'companies' then 'Empresa'
  when 'profiles' then 'Usuários'
  when 'clients' then 'Clientes'
  when 'leads' then 'Leads & CRM'
  when 'suppliers' then 'Fornecedores'
  when 'partners' then 'Parceiros'
  when 'inputs' then 'Insumos / Estoque'
  when 'input_movements' then 'Movimentações de Estoque'
  when 'proposals' then 'Propostas / Projetos'
  when 'proposal_items' then 'Itens da Proposta'
  when 'proposal_models' then 'Modelos de Proposta'
  when 'measurements' then 'Medições'
  when 'purchase_orders' then 'Compras'
  when 'purchase_order_items' then 'Itens de Compra'
  when 'document_templates' then 'Documentos'
  when 'production_projects' then 'Produção'
  when 'cutting_plans' then 'Plano de Corte'
  when 'sheet_remnants' then 'Estoque de Sobras'
  when 'after_sales_tickets' then 'Pós-venda'
  when 'maintenance_orders' then 'Manutenção / OS'
  when 'installation_teams' then 'Equipe de Montagem'
  when 'installation_schedule' then 'Agenda de Montagem'
  when 'cost_centers' then 'Centros de Custo'
  when 'bank_accounts' then 'Contas Bancárias'
  when 'accounts_receivable' then 'Contas a Receber'
  when 'accounts_payable' then 'Contas a Pagar'
  when 'invoices' then 'Notas / Faturas'
  when 'card_machines' then 'Maquininhas'
  when 'finance_entities' then 'Financeiro'
  when 'finance_budgets' then 'Orçamentos Financeiros'
  when 'finance_budget_items' then 'Itens Orçamentários'
  when 'finance_transactions' then 'Transações Financeiras'
  when 'finance_approvals' then 'Aprovações Financeiras'
  when 'profitability_projects' then 'Rentabilidade'
  when 'profitability_assets' then 'Patrimônio'
  when 'profitability_personal_expenses' then 'Despesas Pessoais'
  when 'profitability_settings' then 'Config. Rentabilidade'
  when 'team_cost_members' then 'Custos de Funcionários'
  when 'team_cost_settings' then 'Config. Equipe'
  when 'integrations' then 'Integrações'
  else p_table
 end
$$;

create or replace function public.vimak_audit_row()
returns trigger
language plpgsql
security definer
set search_path=public
as $$
declare
 v_old jsonb;
 v_new jsonb;
 v_company uuid;
 v_record text;
 v_uid uuid;
 v_email text;
 v_name text;
 v_action text;
 v_changed text[] := '{}';
 v_key text;
 v_label text;
 v_summary text;
 v_headers jsonb;
 v_source text := 'VIMAK CRM / API';
begin
 v_old := case when tg_op in ('UPDATE','DELETE') then public.vimak_audit_sanitize(to_jsonb(old)) else null end;
 v_new := case when tg_op in ('INSERT','UPDATE') then public.vimak_audit_sanitize(to_jsonb(new)) else null end;

 if tg_table_name='companies' then
   v_company := coalesce((v_new->>'id')::uuid,(v_old->>'id')::uuid);
 else
   v_company := coalesce(nullif(v_new->>'company_id','')::uuid,nullif(v_old->>'company_id','')::uuid);
 end if;
 if v_company is null then return coalesce(new,old); end if;

 v_record := coalesce(v_new->>'id',v_old->>'id',v_new->>'number',v_old->>'number','—');
 begin v_uid := coalesce(nullif(current_setting('request.jwt.claim.sub',true),'')::uuid,auth.uid()); exception when others then v_uid:=auth.uid(); end;
 begin v_headers := nullif(current_setting('request.headers',true),'')::jsonb; exception when others then v_headers:='{}'::jsonb; end;
 v_source := coalesce(v_headers->>'x-vimak-source','VIMAK CRM / API');

 if v_uid is not null then
   select p.name,coalesce(p.email,(select u.email from auth.users u where u.id=v_uid)) into v_name,v_email from public.profiles p where p.id=v_uid;
   if v_email is null then select email into v_email from auth.users where id=v_uid; end if;
 end if;
 v_name := coalesce(v_name,case when v_uid is null then 'Sistema / Público' else 'Usuário' end);

 if tg_op='INSERT' and tg_table_name='input_movements' then v_action:='MOVIMENTAÇÃO';
 elsif tg_op='INSERT' then v_action:='CADASTRO';
 elsif tg_op='UPDATE' then v_action:='ALTERAÇÃO';
 else v_action:='EXCLUSÃO'; end if;

 if tg_op='UPDATE' then
   for v_key in select jsonb_object_keys(coalesce(v_old,'{}'::jsonb))
   loop
     if v_key <> 'updated_at' and (v_old->v_key) is distinct from (v_new->v_key) then v_changed:=array_append(v_changed,v_key); end if;
   end loop;
 end if;

 v_label := coalesce(v_new->>'name',v_old->>'name',v_new->>'title',v_old->>'title',v_new->>'description',v_old->>'description',v_new->>'sku',v_old->>'sku',v_new->>'number',v_old->>'number',v_record);
 if v_action='CADASTRO' then v_summary:='Cadastrou: '||coalesce(v_label,'registro');
 elsif v_action='EXCLUSÃO' then v_summary:='Excluiu: '||coalesce(v_label,'registro');
 elsif v_action='MOVIMENTAÇÃO' then v_summary:=coalesce(v_new->>'movement_type','Movimentação')||' • Qtd: '||coalesce(v_new->>'qty','—')||' • Saldo: '||coalesce(v_new->>'stock_before','—')||' → '||coalesce(v_new->>'stock_after','—');
 elsif cardinality(v_changed)>0 then v_summary:='Alterou: '||array_to_string(v_changed,', ');
 else v_summary:='Alteração registrada'; end if;

 insert into public.audit_logs(company_id,user_id,user_email,user_name,table_name,record_id,action,operation,old_data,new_data,changed_fields,module,summary,source_app,created_at)
 values(v_company,v_uid,v_email,v_name,tg_table_name,v_record,v_action,tg_op,v_old,v_new,v_changed,public.vimak_audit_module(tg_table_name),v_summary,v_source,now());
 if tg_op='DELETE' then return old; else return new; end if;
end
$$;

-- Impede adulteração do histórico pelo navegador. O trigger SECURITY DEFINER continua gravando normalmente.
drop policy if exists tenant_isolation on public.audit_logs;
drop policy if exists audit_select_company on public.audit_logs;
create policy audit_select_company on public.audit_logs for select to authenticated using(company_id=public.current_company_id());
revoke insert, update, delete on public.audit_logs from anon, authenticated;
grant select on public.audit_logs to authenticated;

-- Tabelas operacionais rastreadas. A lista inclui cadastros, projetos, produção, montagem, estoque e financeiro.
do $$
declare
 t text;
 tables text[] := array[
  'companies','profiles','clients','leads','suppliers','partners','inputs','input_movements',
  'proposals','proposal_items','proposal_models','measurements','purchase_orders','purchase_order_items',
  'document_templates','production_projects','cutting_plans','sheet_remnants','after_sales_tickets','maintenance_orders',
  'integrations','installation_teams','installation_schedule','cost_centers','bank_accounts','accounts_receivable','accounts_payable','invoices','card_machines',
  'finance_entities','finance_budgets','finance_budget_items','finance_transactions','finance_approvals',
  'profitability_projects','profitability_assets','profitability_personal_expenses','profitability_settings','team_cost_members','team_cost_settings'
 ];
begin
 foreach t in array tables loop
   if to_regclass('public.'||t) is not null then
     execute format('drop trigger if exists trg_vimak_audit on public.%I',t);
     execute format('create trigger trg_vimak_audit after insert or update or delete on public.%I for each row execute function public.vimak_audit_row()',t);
   end if;
 end loop;
end $$;

-- Marca a implantação sem auditar a própria tabela de auditoria.
comment on table public.audit_logs is 'Auditoria Geral 360 VIMAK — histórico imutável de ações do CRM e apps integrados.';
