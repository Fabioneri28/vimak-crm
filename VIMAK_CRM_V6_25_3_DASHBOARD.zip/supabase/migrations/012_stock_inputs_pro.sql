-- VIMAK CRM V6.24.13.11 — Estoque & Insumos PRO
ALTER TABLE public.inputs ADD COLUMN IF NOT EXISTS location_street text;
ALTER TABLE public.inputs ADD COLUMN IF NOT EXISTS location_shelf text;
ALTER TABLE public.inputs ADD COLUMN IF NOT EXISTS location_drawer text;
ALTER TABLE public.inputs ADD COLUMN IF NOT EXISTS photo_url text;

CREATE UNIQUE INDEX IF NOT EXISTS inputs_company_sku_unique ON public.inputs(company_id, sku) WHERE sku IS NOT NULL;

CREATE TABLE IF NOT EXISTS public.input_movements (
 id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
 company_id uuid NOT NULL REFERENCES public.companies(id) ON DELETE CASCADE,
 input_id uuid NOT NULL REFERENCES public.inputs(id) ON DELETE CASCADE,
 movement_type text NOT NULL,
 qty numeric(14,4) NOT NULL DEFAULT 0,
 stock_before numeric(14,4) NOT NULL DEFAULT 0,
 stock_after numeric(14,4) NOT NULL DEFAULT 0,
 reason text,
 created_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
 created_at timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE public.input_movements ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS input_movements_company_all ON public.input_movements;
CREATE POLICY input_movements_company_all ON public.input_movements FOR ALL TO authenticated USING (company_id = public.current_company_id()) WITH CHECK (company_id = public.current_company_id());

INSERT INTO storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
VALUES ('input-images','input-images',true,10485760,ARRAY['image/jpeg','image/png','image/webp'])
ON CONFLICT (id) DO UPDATE SET public=true,file_size_limit=10485760,allowed_mime_types=ARRAY['image/jpeg','image/png','image/webp'];

DROP POLICY IF EXISTS input_images_auth_insert ON storage.objects;
DROP POLICY IF EXISTS input_images_auth_update ON storage.objects;
DROP POLICY IF EXISTS input_images_auth_delete ON storage.objects;
CREATE POLICY input_images_auth_insert ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id='input-images');
CREATE POLICY input_images_auth_update ON storage.objects FOR UPDATE TO authenticated USING (bucket_id='input-images') WITH CHECK (bucket_id='input-images');
CREATE POLICY input_images_auth_delete ON storage.objects FOR DELETE TO authenticated USING (bucket_id='input-images');
