-- VIMAK STOCK PRO V2 / CRM V6.24.13.11.7
create table if not exists public.stock_audit_logs (
  id uuid primary key default gen_random_uuid(),
  company_id uuid not null references public.companies(id) on delete cascade,
  user_id uuid null references auth.users(id) on delete set null,
  user_email text,
  user_name text,
  action text not null,
  entity_type text not null default 'input',
  entity_id uuid null,
  sku text,
  before_data jsonb,
  after_data jsonb,
  note text,
  source_app text not null default 'VIMAK Stock Pro',
  created_at timestamptz not null default now()
);
create index if not exists idx_stock_audit_company_created on public.stock_audit_logs(company_id, created_at desc);
create index if not exists idx_stock_audit_company_sku on public.stock_audit_logs(company_id, sku);
alter table public.stock_audit_logs enable row level security;

drop policy if exists stock_audit_select_company on public.stock_audit_logs;
create policy stock_audit_select_company on public.stock_audit_logs
for select to authenticated
using (company_id = public.current_company_id());

drop policy if exists stock_audit_insert_company on public.stock_audit_logs;
create policy stock_audit_insert_company on public.stock_audit_logs
for insert to authenticated
with check (
  company_id = public.current_company_id()
  and (user_id is null or user_id = auth.uid())
);
-- Intencionalmente sem UPDATE/DELETE para usuários autenticados: log imutável.
